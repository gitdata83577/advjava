package com.sunbeam.bean;

public class AnnouncementBean {
	private String msg;

	public AnnouncementBean() {
		
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
